USE [AdventureWorksDW2016];
GO

CREATE SCHEMA [etl] AUTHORIZATION [dbo];
GO

CREATE TABLE [etl].[CountrySales]
(
	[Country] NVARCHAR(50) CONSTRAINT [PK_etl_CountrySales] PRIMARY KEY CLUSTERED
	,[Sales] MONEY NOT NULL
);
GO

CREATE TABLE [etl].[CountrySales_LoadErrors]
(
	[SourceRow] NVARCHAR(MAX) NOT NULL
	,[ErrorCode] INT NOT NULL
	,[ErrorColumn] INT NOT NULL
	,[ErrorColumnName] NVARCHAR(255) NULL
	,[ErrorDescription] NVARCHAR(1000) NULL
);
GO

CREATE TABLE [etl].[PackageExecutionLog]
(
	[PackageName] NVARCHAR(255) NOT NULL
	,[ServerExecutionID] BIGINT NOT NULL
	,[ServerName] NVARCHAR(255) NULL
	,[ExecutionDate] DATETIME CONSTRAINT [DF_etl_PackageExecutionLog_ExecutionDate] DEFAULT (GETDATE())
);
GO
