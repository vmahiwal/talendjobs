SELECT * FROM [AdventureWorksDW2016].[dbo].[FactResellerSalesQuota];
GO