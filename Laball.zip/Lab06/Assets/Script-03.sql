USE [MDS];
GO

/*
This script could fail because the table name is incorrect (as a result of doing prior MDS work before starting this lab).
To fix the script, for the first query, source the correct table name from the [mdm].[tblEntity] table by retrieving the 
[EntityTable] column value for the first listed City entity. For the second query, use the EntityTable value with "_HS" appended.
Also, you will also need to replace the column name used in the WHERE clause for both queries to use the only foreign key (FK) 
column found in the [EntityTable] table.
*/ 

--Retrieve current City entity members for StateProvince AU-WA
SELECT * FROM [mdm].[tbl_1_1_EN] WHERE [uda_1_65] = 72;
GO

--Retrieve City entity row history members for StateProvince AU-WA
SELECT * FROM [mdm].[tbl_1_1_EN_HS] WHERE [uda_1_65] = 72;
GO
