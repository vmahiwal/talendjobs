# BigQueryScript

1. Scripts are used to load data from network share to Google cloud storage
2. Cloud function is used to upload data from Cloud storage to BigQuery  
